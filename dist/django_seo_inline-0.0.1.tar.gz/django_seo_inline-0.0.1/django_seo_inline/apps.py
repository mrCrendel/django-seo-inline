from django.apps import AppConfig


class DjangoSimpleSeoConfig(AppConfig):
    name = 'django_seo_inline'
